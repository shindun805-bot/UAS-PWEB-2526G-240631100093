# 📚 Sistem Pendataan Buku

## Deskripsi

Sistem Pendataan Buku merupakan aplikasi berbasis web sederhana yang dibuat menggunakan **PHP Native** dan **MySQL**. Aplikasi ini bertujuan untuk membantu pengguna dalam mengelola data buku secara mudah dan efisien melalui penerapan konsep **CRUD (Create, Read, Update, Delete)**.

Website ini dikembangkan sebagai tugas **Ujian Akhir Semester (UAS)** mata kuliah **Pemrograman Web**. Selain menerapkan operasi CRUD, aplikasi ini juga dilengkapi dengan fitur **Login** menggunakan **Session** sehingga hanya pengguna yang berhasil melakukan login yang dapat mengakses sistem.

---

# Tujuan Pembuatan

Tujuan pembuatan website ini adalah:

* Memenuhi tugas Ujian Akhir Semester mata kuliah Pemrograman Web.
* Menerapkan konsep CRUD menggunakan PHP Native dan MySQL.
* Mempelajari koneksi antara PHP dan database MySQL.
* Menerapkan sistem Login menggunakan Session.
* Membuat antarmuka website yang sederhana, menarik, dan mudah digunakan.

---

# Fitur Website

Website ini memiliki beberapa fitur utama, yaitu:

* ✅ Login Admin
* ✅ Halaman Home
* ✅ Tambah Data Buku
* ✅ Menampilkan Daftar Buku
* ✅ Edit Data Buku
* ✅ Hapus Data Buku
* ✅ Logout

---

# Teknologi yang Digunakan

Aplikasi ini dibuat menggunakan teknologi berikut:

* PHP Native
* HTML5
* CSS3
* JavaScript
* MySQL
* XAMPP
* Visual Studio Code

---

# Struktur Folder Project

```
UAS-PWEB-2526G-240631100093
│
├── assets
│   ├── logo.png
│   └── style.css
│
├── koneksi.php
├── function.php
├── login.php
├── logout.php
├── index.php
├── tambah.php
├── daftar.php
├── edit.php
├── hapus.php
├── database.sql
└── README.md
```

---

# Penjelasan Setiap File

## 1. login.php

Berfungsi sebagai halaman Login Administrator.

Pada halaman ini pengguna memasukkan username dan password. Apabila data yang dimasukkan benar maka sistem akan membuat Session Login dan mengarahkan pengguna menuju halaman Home.

---

## 2. logout.php

Digunakan untuk menghapus Session Login sehingga pengguna keluar dari sistem dan kembali ke halaman Login.

---

## 3. koneksi.php

File ini digunakan untuk menghubungkan website dengan database MySQL menggunakan fungsi `mysqli_connect()`.

Seluruh proses CRUD memerlukan file ini agar dapat mengakses database.

---

## 4. function.php

Berisi kumpulan function yang digunakan oleh beberapa halaman.

Tujuannya agar kode lebih rapi dan tidak perlu ditulis berulang.

---

## 5. index.php

Merupakan halaman utama (Home).

Pada halaman ini ditampilkan informasi mengenai aplikasi beserta jumlah data buku yang tersimpan pada database.

---

## 6. tambah.php

Digunakan untuk menambahkan data buku baru ke database menggunakan perintah SQL **INSERT**.

---

## 7. daftar.php

Digunakan untuk menampilkan seluruh data buku yang tersimpan di database menggunakan perintah SQL **SELECT**.

---

## 8. edit.php

Digunakan untuk mengubah data buku yang sudah tersimpan menggunakan perintah SQL **UPDATE**.

---

## 9. hapus.php

Digunakan untuk menghapus data buku menggunakan perintah SQL **DELETE**.

Sebelum data dihapus, sistem akan menampilkan konfirmasi terlebih dahulu.

---

## 10. assets/style.css

Berfungsi untuk mengatur tampilan website, seperti:

* Warna Website
* Font
* Header
* Navbar
* Form
* Tombol
* Tabel
* Footer

---

# Hubungan Antar File

Berikut alur hubungan antar file pada website.

```
Login
   │
   ▼
login.php
   │
   ▼
index.php
   │
   ├──────────────┐
   │              │
   ▼              ▼
tambah.php    daftar.php
                   │
                   ▼
              edit.php
                   │
                   ▼
              hapus.php
                   │
                   ▼
               logout.php
```

Seluruh halaman tersebut menggunakan:

* koneksi.php
* function.php

untuk mengakses database dan menjalankan beberapa fungsi yang digunakan bersama.

---

# Konsep CRUD

Website ini menerapkan konsep CRUD.

## Create

Menambahkan data buku baru ke database.

Dilakukan pada halaman:

```
tambah.php
```

Menggunakan perintah SQL:

```
INSERT INTO
```

---

## Read

Menampilkan seluruh data buku yang tersimpan.

Dilakukan pada halaman:

```
daftar.php
```

Menggunakan perintah SQL:

```
SELECT
```

---

## Update

Mengubah data buku.

Dilakukan pada halaman:

```
edit.php
```

Menggunakan perintah SQL:

```
UPDATE
```

---

## Delete

Menghapus data buku.

Dilakukan pada halaman:

```
hapus.php
```

Menggunakan perintah SQL:

```
DELETE
```

---

# Cara Menjalankan Project

1. Install XAMPP.
2. Jalankan Apache dan MySQL.
3. Buka phpMyAdmin.
4. Buat database.
5. Import file `database.sql`.
6. Salin folder project ke dalam folder `htdocs`.
7. Jalankan browser.
8. Buka alamat:

```
http://localhost/UAS-PWEB-2526G-240631100093/login.php
```

---

# Akun Login

Gunakan akun berikut untuk masuk ke dalam sistem.

**Username**

```
admin
```

**Password**

```
admin123
```

---

# Alur Penggunaan Sistem

1. Pengguna membuka halaman Login.
2. Pengguna memasukkan Username dan Password.
3. Sistem melakukan proses autentikasi.
4. Jika Login berhasil maka pengguna masuk ke halaman Home.
5. Pengguna dapat:

   * Menambah data buku
   * Melihat daftar buku
   * Mengubah data buku
   * Menghapus data buku
6. Setelah selesai, pengguna dapat Logout sehingga Session Login berakhir.

---

# Tampilan Website

Halaman yang tersedia pada website antara lain:

* Halaman Login
* Halaman Home
* Halaman Tambah Buku
* Halaman Daftar Buku
* Halaman Edit Buku
* Konfirmasi Hapus
* Logout

*(Tambahkan screenshot setiap halaman apabila diperlukan.)*

---

# Kelebihan Website

* Tampilan sederhana dan mudah digunakan.
* Menggunakan PHP Native sehingga mudah dipahami.
* Sudah menerapkan Login menggunakan Session.
* Menggunakan database MySQL.
* Mendukung operasi CRUD secara lengkap.
* Memiliki konfirmasi sebelum menghapus data.
* Struktur kode dipisahkan agar lebih rapi.

---

# Kekurangan Website

Beberapa fitur yang masih dapat dikembangkan, antara lain:

* Belum mendukung upload gambar cover buku.
* Belum tersedia fitur pencarian data.
* Belum menggunakan password yang di-hash.
* Belum memiliki manajemen banyak pengguna (multi-user).

---

# Identitas Pembuat

**Nama** : Siti Hindun

**NIM** : 240631100093

**Mata Kuliah** : Pemrograman Web

**Semester** : Genap 2025/2026

---

# Kesimpulan

Website **Sistem Pendataan Buku** berhasil dibuat menggunakan PHP Native dan MySQL. Website ini telah menerapkan fitur CRUD (Create, Read, Update, Delete), autentikasi Login menggunakan Session, serta antarmuka berbasis HTML, CSS, dan JavaScript.

Melalui proyek ini diperoleh pemahaman mengenai pembuatan aplikasi web sederhana mulai dari proses perancangan database, pembuatan halaman web, pengolahan data menggunakan PHP, hingga implementasi koneksi dengan database MySQL. Website ini diharapkan dapat menjadi dasar untuk pengembangan aplikasi yang lebih kompleks di masa mendatang.
